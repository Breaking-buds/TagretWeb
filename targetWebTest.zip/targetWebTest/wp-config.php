<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en « wp-config.php » et remplir les
 * valeurs.
 *
 * Ce fichier contient les réglages de configuration suivants :
 *
 * Réglages MySQL
 * Préfixe de table
 * Clés secrètes
 * Langue utilisée
 * ABSPATH
 *
 * @link https://fr.wordpress.org/support/article/editing-wp-config-php/.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'targetweb' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'root' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', '' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/**
 * Type de collation de la base de données.
 * N’y touchez que si vous savez ce que vous faites.
 */
define( 'DB_COLLATE', '' );

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clés secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'W!u@tefnN_&.{i~GO^31Q5W (-O+_$=}j#ea7-ywUpwdAMjU ^~dK/P(n6RtC]yy' );
define( 'SECURE_AUTH_KEY',  '}l@&Ho7K=FdKF,qLSp6fr~jSEKl=~X?vkX.* AkLyS&>{7VFMg-STkg^VX(2y:lN' );
define( 'LOGGED_IN_KEY',    'Nr{p%H1+k08-f,/3nn{jJPzEw>!579~fIYQ5bok_}mfz0+@V%x[%/frF{T^V%Wb>' );
define( 'NONCE_KEY',        'B2y%]kI}$5so?T4!.gIHYx*ATZ2#@;~Az7e*L)&:zk<x>{8#iO : s~F2:$_s`);' );
define( 'AUTH_SALT',        '*K]1sThaw4vBx_SNEo4vo5_T8]o>WrO[BF.pE}[R)UYRM}5vGxe&9m@f /vCeyIF' );
define( 'SECURE_AUTH_SALT', 'X|^&G]3~m|QN&dta_1[WXRhjPl1P^ZFp90}A-Ir*(Xq9nI3!si|d)^[c.P*QJ%Sn' );
define( 'LOGGED_IN_SALT',   'H*rp/2}ZjxqX,=dc>wH&o.3,(BG~`WhoaG*,9k nj60YQDG4?T_13k<Mk7i:u*%4' );
define( 'NONCE_SALT',       '@:21~fc ,iN6J!m2Wz0)kgX:9^a.VClX.6amg|{D$x|_?Zt^W*;k;AClJlE)!KO{' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'ttw_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortement recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://fr.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( ! defined( 'ABSPATH' ) )
  define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once( ABSPATH . 'wp-settings.php' );
